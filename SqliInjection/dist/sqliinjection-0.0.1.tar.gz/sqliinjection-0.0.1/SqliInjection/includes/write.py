def write(output,data):
    with open(output,"a") as file:
        file.write(data)