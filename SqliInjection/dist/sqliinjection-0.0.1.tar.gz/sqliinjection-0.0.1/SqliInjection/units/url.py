class data:
    blog = "https://medium.com/purplebox/sql-injection-da949c39dbe6"